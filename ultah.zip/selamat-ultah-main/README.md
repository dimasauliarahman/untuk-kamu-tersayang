# Ucapan Selamat Ulang Tahun
Sangat simple, ketika surat di klik, akan keluar ucapan dan seketika terputar sebuah lagu. Belum 100% jadi, kurang smooth dan lain-lain.

Lihat [Demo](https://strbagus.github.io/selamat-ultah/).

Versi Upgrade Dinamis: [Version2](https://github.com/strbagus/ucapan-v2).
